# 🚖 Guía Completa - Taxi Quilichao
## Cómo llevar todo el proyecto a producción

---

## ¿Qué necesitas tener instalado en tu computador?

| Herramienta | Para qué | Dónde descargarlo |
|-------------|----------|-------------------|
| **Node.js v18+** | Correr el backend | nodejs.org |
| **PostgreSQL 14+** | Base de datos | postgresql.org |
| **Expo Go** (en el celular) | Probar la app móvil | App Store / Play Store |
| **Git** (opcional) | Control de versiones | git-scm.com |

---

## PASO 1 — Configurar la base de datos

### 1.1 Abrir PostgreSQL y crear la base de datos

En la terminal de tu computador:

```bash
# Entrar a PostgreSQL
psql -U postgres

# Crear la base de datos
CREATE DATABASE taxi_quilichao;

# Salir
\q
```

### 1.2 Ejecutar las migraciones (crea todas las tablas)

```bash
cd taxi-quilichao/backend
npm install
npm run migrate
```

Deberías ver:
```
✅ 001_crear_tablas.sql ejecutado correctamente
✅ 002_push_token.sql ejecutado correctamente
✅ Todas las migraciones completadas
```

### 1.3 Insertar datos de prueba

```bash
npm run seed
```

Esto crea 4 usuarios de prueba listos para usar.

---

## PASO 2 — Configurar el Backend

### 2.1 Crear el archivo de configuración

```bash
cd taxi-quilichao/backend
cp .env.example .env
```

Abre el archivo `.env` con cualquier editor de texto y llénalo:

```env
PORT=3000
NODE_ENV=development

# Base de datos
DB_HOST=localhost
DB_PORT=5432
DB_NAME=taxi_quilichao
DB_USER=postgres
DB_PASSWORD=la_contraseña_de_tu_postgres

# JWT (puedes poner cualquier texto largo y secreto)
JWT_SECRET=taxi_quilichao_clave_super_secreta_2024

# Google Maps (ver Paso 5)
GOOGLE_MAPS_API_KEY=tu_clave_aqui

# Tarifas en pesos colombianos
TARIFA_BASE=3000
TARIFA_POR_KM=1200
TARIFA_MINIMA=4000
```

### 2.2 Iniciar el servidor

```bash
npm run dev
```

Deberías ver:
```
✅ Conectado a PostgreSQL
🚖 Taxi Quilichao API corriendo en puerto 3000
📍 http://localhost:3000/api/health
```

### 2.3 Verificar que funciona

Abre tu navegador y ve a:
```
http://localhost:3000/api/health
```

Deberías ver: `{"status":"ok","app":"Taxi Quilichao API"}`

---

## PASO 3 — Configurar la App Móvil

### 3.1 Instalar dependencias

```bash
cd taxi-quilichao/mobile
npm install
```

### 3.2 ⚠️ Encontrar tu IP local (MUY IMPORTANTE)

El celular y el computador deben estar en el **mismo WiFi**.

**En Windows:**
```
ipconfig
```
Busca "Dirección IPv4", algo como `192.168.1.5`

**En Mac/Linux:**
```
ifconfig | grep inet
```

### 3.3 Configurar la URL del servidor en la app

Abre el archivo `mobile/src/services/api.js` y cambia:

```javascript
// Cambia esto:
export const API_URL = 'http://192.168.1.100:3000/api';
export const SOCKET_URL = 'http://192.168.1.100:3000';

// Por tu IP real, ejemplo:
export const API_URL = 'http://192.168.1.5:3000/api';
export const SOCKET_URL = 'http://192.168.1.5:3000';
```

### 3.4 Iniciar la app

```bash
npm start
```

Se abrirá una ventana con un **código QR**.

### 3.5 Instalar Expo Go en el celular

- **Android**: Busca "Expo Go" en Play Store
- **iPhone**: Busca "Expo Go" en App Store

### 3.6 Escanear el QR

- **Android**: Abre la app Expo Go y escanea el QR
- **iPhone**: Escanea el QR directamente con la cámara

La app debería abrirse en tu celular en menos de 1 minuto.

---

## PASO 4 — Probar el sistema completo

### Prueba rápida con las credenciales de prueba

| Rol | Celular | Contraseña |
|-----|---------|------------|
| Pasajero | 3001000003 | password123 |
| Conductor | 3001000002 | password123 |
| Propietario | 3001000001 | password123 |
| Admin | 3001000000 | password123 |

### Flujo de prueba completo

1. **En un celular (o pestaña)**: Inicia sesión como **Conductor**
   - Activa el interruptor de disponibilidad
   - Verás el punto verde indicando que estás disponible

2. **En otro celular (o simulador)**: Inicia sesión como **Pasajero**
   - Selecciona un destino
   - Toca "Pedir taxi"

3. **En el celular del Conductor**: Debería llegar la solicitud con vibración
   - Toca "Aceptar"

4. **En el celular del Pasajero**: Verás el conductor asignado

5. **El conductor** toca "Recogí al pasajero" → luego "Llegué al destino"

6. **Ambos** se califican mutuamente

---

## PASO 5 — Google Maps API (para el mapa real)

Sin esto el mapa aparece en gris. Es gratis para empezar.

### 5.1 Crear cuenta en Google Cloud

Ve a: **console.cloud.google.com**

### 5.2 Activar las APIs necesarias

En el buscador de Google Cloud, activa estas 3 APIs:
- Maps SDK for Android
- Maps SDK for iOS
- Directions API

### 5.3 Crear una clave API

Ve a **APIs & Services → Credentials → Create Credentials → API Key**

Copia la clave y pégala en:
- El archivo `.env` del backend: `GOOGLE_MAPS_API_KEY=tu_clave`
- El archivo `app.json` del mobile: agregar `"googleMapsApiKey": "tu_clave"` en la sección android

### 5.4 Cuánto cuesta

Google da **$200 USD gratis al mes** en créditos. Para una ciudad pequeña como Santander de Quilichao, esto es más que suficiente para empezar (cientos de miles de requests).

---

## PASO 6 — Notificaciones Push

### 6.1 Crear cuenta en Expo

Ve a **expo.dev** y crea una cuenta gratuita.

### 6.2 Obtener tu Project ID

```bash
cd mobile
npx expo login
npx expo whoami
```

Ve a expo.dev/accounts → tu proyecto → copia el **Project ID**

### 6.3 Configurarlo en la app

Abre `mobile/src/services/notificaciones.js` y cambia:

```javascript
const tokenData = await Notifications.getExpoPushTokenAsync({
  projectId: 'tu-project-id-aqui', // ← Pega tu Project ID
});
```

### 6.4 Probar notificaciones

Usa la herramienta gratuita de Expo: **expo.dev/notifications**

Pega un token push y envía una notificación de prueba.

---

## PASO 7 — Llevar a producción (cuando estés listo)

### Opción A: Servidor barato en la nube (~$10/mes)

**Railway.app** (el más fácil):
1. Crea cuenta en railway.app
2. Conecta tu repositorio de GitHub
3. Railway detecta Node.js y despliega automáticamente
4. Agrega PostgreSQL con un clic
5. Configura las variables de entorno en el panel

**Render.com** (también fácil):
- Similar a Railway, también tiene plan gratuito para empezar

### Opción B: VPS en Colombia (~$8-15/mes)

Proveedores con servidores en Colombia o cerca:
- **DigitalOcean** (droplet básico $6/mes)
- **Hetzner** (el más barato, ~$4/mes)
- **OVH** (tiene datacenter en Brasil, más cercano)

### Publicar la app en las tiendas

**Android (Play Store)**:
```bash
cd mobile
npx expo build:android
```
Cuesta $25 USD una sola vez para abrir cuenta de desarrollador.

**iPhone (App Store)**:
```bash
npx expo build:ios
```
Cuesta $99 USD al año para la cuenta de desarrollador Apple.

> 💡 **Alternativa gratis**: Distribuye la app directamente con Expo Go para las primeras pruebas con conductores reales. No necesitas publicarla en las tiendas para empezar a operar.

---

## Resumen del orden de trabajo

```
1. Instalar PostgreSQL y Node.js en tu computador
2. npm install en /backend → npm run migrate → npm run seed
3. Configurar .env con tu password de Postgres
4. npm run dev → verificar en localhost:3000/api/health
5. npm install en /mobile
6. Cambiar la IP en mobile/src/services/api.js
7. npm start en /mobile → escanear QR con Expo Go
8. Probar login con usuarios de prueba
9. Crear clave de Google Maps y configurar
10. ¡Listo para probar con conductores y pasajeros reales!
```

---

## ¿Tienes problemas?

| Error | Solución |
|-------|----------|
| `Error: connect ECONNREFUSED` | El backend no está corriendo. Ejecuta `npm run dev` en la carpeta backend |
| `Network request failed` en la app | La IP en `api.js` está mal. Verifica con `ipconfig` |
| Mapa en gris | Falta la clave de Google Maps |
| `JWT_SECRET is not defined` | Falta crear el archivo `.env` |
| La app no carga | Celular y computador deben estar en el mismo WiFi |
| Notificaciones no llegan | Solo funcionan en celular físico, no en simulador |
